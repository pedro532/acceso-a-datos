import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const CalculadoraIMC = () => {
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [resultado, setResultado] = useState('');

  const calcularIMC = () => {
    const pesoFloat = parseFloat(peso);
    const alturaFloat = parseFloat(altura) / 100;

    if (!isNaN(pesoFloat) && !isNaN(alturaFloat) && alturaFloat > 0) {
      const imc = pesoFloat / (alturaFloat * alturaFloat);
      setResultado(imc.toFixed(2));

      if (imc < 18.5) {
        setResultado('Peso insuficiente');
      } else if (imc < 25) {
        setResultado('Normopeso');
      } else if (imc < 27) {
        setResultado('Sobrepeso grado I');
      } else if (imc < 30) {
        setResultado('Sobrepeso grado II (preobesidad)');
      } else if (imc < 35) {
        setResultado('Obesidad de tipo I');
      } else if (imc < 40) {
        setResultado('Obesidad de tipo II');
      } else if (imc < 50) {
        setResultado('Obesidad de tipo III (mórbida)');
      } else {
        setResultado('Obesidad de tipo IV (extrema)');
      }
    } else {
      setResultado('Por favor, ingresa valores válidos.');
    }
  };

   return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Calculadora IMC</Text>
      <View style={styles.innerContainer}>
        <Text style={styles.datosTitulo}>Datos</Text>

        <Text style={styles.etiquetaAzul}>Peso</Text>
        <TextInput
          keyboardType="numeric"
          value={peso}
          onChangeText={(text) => setPeso(text)}
          style={styles.textInput}
        />

        <Text style={styles.etiquetaAzul}>Altura</Text>
        <TextInput
          keyboardType="numeric"
          value={altura}
          onChangeText={(text) => setAltura(text)}
          style={styles.textInput}
        />

        <TouchableOpacity
          style={styles.botonBlanco}
          onPress={calcularIMC}
        >
          <Text style={styles.textoBotonAzul}>Calcular IMC</Text>
        </TouchableOpacity>

        <Text style={styles.resultadoTitulo}>Resultado</Text>
        <Text style={styles.resultado}>{resultado}</Text>
      </View>

      <Text style={styles.footer}>Created for 2n DAM</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'purple',
  },
  titulo: {
    color: 'red',
    fontSize: 24,
    marginBottom: 16,
  },
  datosTitulo: {
    color: 'red',
    fontSize: 18,
    marginBottom: 8,
  },
  etiquetaAzul: {
    color: 'blue',
  },
  innerContainer: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 10,
    width: '80%',
  },
  textInput: {
    borderBottomWidth: 1,
    marginBottom: 10,
  },
  botonBlanco: {
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
    borderWidth: 2,
    borderColor: 'blue',
    alignItems: 'center',
  },
  textoBotonAzul: {
    color: 'blue',
  },
  resultadoTitulo: {
    color: 'black',
    fontSize: 16,
    marginTop: 10,
  },
  resultado: {
    color: 'orange',
    fontSize: 20,
    fontWeight: 'bold',
  },
  footer: {
    color: 'gray',
    marginTop: 10,
    alignSelf: 'flex-start',
    marginLeft: '10%',
  },
});

export default CalculadoraIMC;